package com.example.data.auth

import android.content.Context
import android.content.SharedPreferences
import com.example.data.local.SocialAccountEntity

/**
 * SessionManager tracks persistent sessions, active multi-account targets per platform,
 * and session state recovery.
 */
class SessionManager(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("user_sessions", Context.MODE_PRIVATE)

    fun setActiveAccountId(platform: String, accountId: Long) {
        prefs.edit().putLong("active_account_$platform", accountId).apply()
    }

    fun getActiveAccountId(platform: String): Long {
        return prefs.getLong("active_account_$platform", -1L)
    }

    fun setSessionActive(platform: String, isActive: Boolean) {
        prefs.edit().putBoolean("session_active_$platform", isActive).apply()
    }

    fun isSessionActive(platform: String): Boolean {
        return prefs.getBoolean("session_active_$platform", true)
    }

    fun clearSession(platform: String) {
        prefs.edit()
            .remove("active_account_$platform")
            .remove("session_active_$platform")
            .apply()
    }
}
