package com.example.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface TrendDao {
    @Query("SELECT * FROM trend_topics ORDER BY score DESC")
    fun getAllTrends(): Flow<List<TrendTopicEntity>>

    @Query("SELECT * FROM trend_topics WHERE category = :category ORDER BY score DESC")
    fun getTrendsByCategory(category: String): Flow<List<TrendTopicEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrends(trends: List<TrendTopicEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrend(trend: TrendTopicEntity)

    @Query("UPDATE trend_topics SET isSaved = :isSaved WHERE id = :id")
    suspend fun updateSaveStatus(id: Long, isSaved: Boolean)

    @Query("DELETE FROM trend_topics")
    suspend fun deleteAllTrends()
}
