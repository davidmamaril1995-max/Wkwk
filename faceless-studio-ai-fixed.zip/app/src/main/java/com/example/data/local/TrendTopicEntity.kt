package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "trend_topics")
data class TrendTopicEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val topicTitle: String,
    val category: String,
    val score: Int, // 1 to 100 virality score
    val summary: String,
    val targetAudience: String,
    val recommendedPlatforms: String,
    val isSaved: Boolean = false,
    val searchVolume: String = "High",
    val createdAt: Long = System.currentTimeMillis()
)
