package com.example.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(
    val route: String,
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
) {
    object Home : Screen(
        route = "home",
        title = "Command",
        selectedIcon = Icons.Filled.RocketLaunch,
        unselectedIcon = Icons.Outlined.RocketLaunch,
        testTag = "nav_home_tab"
    )

    object VideoLibrary : Screen(
        route = "video_library",
        title = "Library",
        selectedIcon = Icons.Filled.VideoLibrary,
        unselectedIcon = Icons.Outlined.VideoLibrary,
        testTag = "nav_video_library_tab"
    )

    object SocialCommand : Screen(
        route = "social_command",
        title = "Social Hub",
        selectedIcon = Icons.Filled.Hub,
        unselectedIcon = Icons.Outlined.Hub,
        testTag = "nav_social_command_tab"
    )

    object Create : Screen(
        route = "create",
        title = "Content Lab",
        selectedIcon = Icons.Filled.AutoAwesome,
        unselectedIcon = Icons.Outlined.AutoAwesome,
        testTag = "nav_create_tab"
    )

    object Calendar : Screen(
        route = "calendar",
        title = "Calendar",
        selectedIcon = Icons.Filled.CalendarMonth,
        unselectedIcon = Icons.Outlined.CalendarMonth,
        testTag = "nav_calendar_tab"
    )

    object Projects : Screen(
        route = "projects",
        title = "Workspaces",
        selectedIcon = Icons.Filled.FolderSpecial,
        unselectedIcon = Icons.Outlined.FolderSpecial,
        testTag = "nav_projects_tab"
    )

    object Trending : Screen(
        route = "trending",
        title = "Signals",
        selectedIcon = Icons.Filled.Radar,
        unselectedIcon = Icons.Outlined.Radar,
        testTag = "nav_trending_tab"
    )

    object Analytics : Screen(
        route = "analytics",
        title = "Stats",
        selectedIcon = Icons.Filled.Insights,
        unselectedIcon = Icons.Outlined.Insights,
        testTag = "nav_analytics_tab"
    )

    object Settings : Screen(
        route = "settings",
        title = "Settings",
        selectedIcon = Icons.Filled.Tune,
        unselectedIcon = Icons.Outlined.Tune,
        testTag = "nav_settings_tab"
    )
}

val primaryBottomNavScreens = listOf(
    Screen.Home,
    Screen.VideoLibrary,
    Screen.Create,
    Screen.SocialCommand,
    Screen.Calendar,
    Screen.Projects,
    Screen.Analytics
)
