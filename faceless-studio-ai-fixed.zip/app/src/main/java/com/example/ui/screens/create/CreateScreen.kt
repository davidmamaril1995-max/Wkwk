package com.example.ui.screens.create

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.theme.*
import com.example.ui.viewmodels.AiAssistantState
import com.example.ui.viewmodels.FacelessViewModel
import com.example.ui.viewmodels.ScriptGenerationState
import java.text.SimpleDateFormat
import java.util.*

val voiceoverOptions = listOf("Deep Space Cinematic", "Quantum Storyteller", "Dark Nebula", "Galactic Tech", "Solar Chill")
val visualStyles = listOf("Cyberpunk 3D", "Intergalactic Sci-Fi", "Photorealistic Space", "Minimalist Vector")
val allSocialPlatforms = listOf("YouTube", "TikTok", "Facebook", "Instagram", "Threads", "Pinterest", "X")
val contentTypesList = listOf("Short Video", "Long Video", "Reel", "Post", "Carousel")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateScreen(
    viewModel: FacelessViewModel,
    initialTopic: String = "",
    initialNiche: String = "",
    onProjectCreated: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) } // 0 = Unified Creation Workflow, 1 = Galactic AI Assistant

    // Step 1: Content Type
    var selectedContentType by remember { mutableStateOf("Short Video") }

    // Step 2: Topic & Media Source
    var topicInput by remember { mutableStateOf(initialTopic) }
    var selectedNiche by remember { mutableStateOf(initialNiche.ifBlank { "Tech & AI" }) }

    // Step 3: Script & Styling
    var selectedVoiceover by remember { mutableStateOf("Deep Space Cinematic") }
    var selectedFormat by remember { mutableStateOf("9:16") }
    var selectedVisualStyle by remember { mutableStateOf("Cyberpunk 3D") }
    var generatedHook by remember { mutableStateOf("") }
    var generatedScript by remember { mutableStateOf("") }
    var generatedCta by remember { mutableStateOf("") }

    // Step 5: Platforms
    val selectedPlatforms = remember { mutableStateListOf("YouTube", "TikTok", "Instagram", "Facebook", "X") }

    // Step 6: Publish Method
    var isScheduled by remember { mutableStateOf(false) }
    var scheduledDateText by remember { mutableStateOf("2026-07-25") }
    var scheduledTimeText by remember { mutableStateOf("18:00") }
    var selectedTimeZone by remember { mutableStateOf("UTC") }

    val scriptState by viewModel.scriptState.collectAsStateWithLifecycle()
    val aiAssistantState by viewModel.aiAssistantState.collectAsStateWithLifecycle()
    var isPreviewPlaying by remember { mutableStateOf(false) }

    LaunchedEffect(scriptState) {
        if (scriptState is ScriptGenerationState.Success) {
            val state = scriptState as ScriptGenerationState.Success
            generatedHook = state.hookText
            generatedScript = state.scriptBody
            generatedCta = state.ctaText
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = NebulaPurple, modifier = Modifier.size(24.dp))
                        Text(
                            text = "Unified Creation Workflow",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = TextPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = StudioDarkBackground)
            )
        },
        containerColor = StudioDarkBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Creation Mode Tab Header
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = StudioDarkSurface,
                contentColor = CosmicCyan,
                divider = { HorizontalDivider(color = StudioBorder) }
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("7-Step Workflow", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Galactic AI Assistant", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                )
            }

            if (selectedTab == 1) {
                GalacticAiAssistantSection(
                    viewModel = viewModel,
                    topicInput = topicInput,
                    onTopicChange = { topicInput = it },
                    aiAssistantState = aiAssistantState
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // STEP 1: Content Type
                    item {
                        WorkflowStepCard(stepNumber = "1", title = "Choose Content Type") {
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(contentTypesList) { type ->
                                    val isSelected = selectedContentType == type
                                    FilterChip(
                                        selected = isSelected,
                                        onClick = { selectedContentType = type },
                                        label = {
                                            Text(
                                                text = type,
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                                color = if (isSelected) OnPurpleContainer else TextSecondary
                                            )
                                        },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = PurpleContainer,
                                            containerColor = StudioDarkSurfaceVariant
                                        )
                                    )
                                }
                            }
                        }
                    }

                    // STEP 2: Topic & Generation
                    item {
                        WorkflowStepCard(stepNumber = "2", title = "Upload Media or Generate Content") {
                            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                OutlinedTextField(
                                    value = topicInput,
                                    onValueChange = { topicInput = it },
                                    label = { Text("Video Topic or Cosmic Concept") },
                                    placeholder = { Text("e.g. 5 AI Secrets Revolutionizing Passive Income") },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("create_topic_input"),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = customTextFieldColors()
                                )

                                Text("Galactic Category", fontSize = 12.sp, color = TextSecondary)
                                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    items(listOf("Tech & AI", "Personal Finance", "Sci-Fi & Space", "Horror & Mystery", "Life Hacks")) { cat ->
                                        val isSelected = selectedNiche == cat
                                        FilterChip(
                                            selected = isSelected,
                                            onClick = { selectedNiche = cat },
                                            label = { Text(cat) },
                                            colors = FilterChipDefaults.filterChipColors(
                                                selectedContainerColor = CyanContainer,
                                                selectedLabelColor = OnCyanContainer
                                            )
                                        )
                                    }
                                }

                                Button(
                                    onClick = {
                                        if (topicInput.isNotBlank()) {
                                            viewModel.generateScript(topicInput, selectedNiche, selectedFormat)
                                        }
                                    },
                                    enabled = topicInput.isNotBlank() && scriptState !is ScriptGenerationState.Loading,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("generate_script_btn"),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = NebulaPurple)
                                ) {
                                    if (scriptState is ScriptGenerationState.Loading) {
                                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Synthesizing Script & Hooks...", color = Color.White)
                                    } else {
                                        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color.White)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("AI Synthesize Script", fontWeight = FontWeight.Bold, color = Color.White)
                                    }
                                }
                            }
                        }
                    }

                    // STEP 3: Edit Content
                    item {
                        WorkflowStepCard(stepNumber = "3", title = "Edit Content Script & Voice Style") {
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                OutlinedTextField(
                                    value = generatedHook,
                                    onValueChange = { generatedHook = it },
                                    label = { Text("Attention Hook") },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(10.dp),
                                    colors = customTextFieldColors()
                                )

                                OutlinedTextField(
                                    value = generatedScript,
                                    onValueChange = { generatedScript = it },
                                    label = { Text("Voiceover Narration Script Body") },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(10.dp),
                                    colors = customTextFieldColors(),
                                    minLines = 3
                                )

                                OutlinedTextField(
                                    value = generatedCta,
                                    onValueChange = { generatedCta = it },
                                    label = { Text("Call To Action (CTA)") },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(10.dp),
                                    colors = customTextFieldColors()
                                )

                                Text("Voiceover Voice", fontSize = 12.sp, color = TextSecondary)
                                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    items(voiceoverOptions) { v ->
                                        val isSel = selectedVoiceover == v
                                        FilterChip(
                                            selected = isSel,
                                            onClick = { selectedVoiceover = v },
                                            label = { Text(v) },
                                            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = PurpleContainer)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // STEP 4: Preview Content
                    item {
                        WorkflowStepCard(stepNumber = "4", title = "Preview Content") {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(180.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(
                                        Brush.verticalGradient(
                                            listOf(NebulaPurpleDark, StudioDarkSurfaceVariant)
                                        )
                                    )
                                    .border(1.dp, StudioBorder, RoundedCornerShape(14.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.padding(12.dp)
                                ) {
                                    IconButton(
                                        onClick = { isPreviewPlaying = !isPreviewPlaying },
                                        modifier = Modifier.background(CosmicCyan, CircleShape)
                                    ) {
                                        Icon(
                                            imageVector = if (isPreviewPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                            contentDescription = null,
                                            tint = StudioDarkBackground
                                        )
                                    }

                                    Text(
                                        text = if (generatedHook.isNotBlank()) generatedHook else "Live AI Render Preview Area",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = StarGold
                                    )

                                    Text(
                                        text = "Voice: $selectedVoiceover • Format: $selectedContentType ($selectedFormat)",
                                        fontSize = 10.sp,
                                        color = TextSecondary
                                    )
                                }
                            }
                        }
                    }

                    // STEP 5: Destination Platforms
                    item {
                        WorkflowStepCard(stepNumber = "5", title = "Choose Destination Platforms") {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                allSocialPlatforms.forEach { platform ->
                                    val isChecked = selectedPlatforms.contains(platform)
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                if (isChecked) selectedPlatforms.remove(platform)
                                                else selectedPlatforms.add(platform)
                                            },
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Checkbox(
                                            checked = isChecked,
                                            onCheckedChange = {
                                                if (it) selectedPlatforms.add(platform)
                                                else selectedPlatforms.remove(platform)
                                            },
                                            colors = CheckboxDefaults.colors(checkedColor = NebulaPurple)
                                        )
                                        Text(platform, fontSize = 14.sp, color = TextPrimary, fontWeight = FontWeight.Medium)
                                    }
                                }
                            }
                        }
                    }

                    // STEP 6: Publish Method
                    item {
                        WorkflowStepCard(stepNumber = "6", title = "Choose Publish Method") {
                            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.clickable { isScheduled = false }
                                    ) {
                                        RadioButton(
                                            selected = !isScheduled,
                                            onClick = { isScheduled = false },
                                            colors = RadioButtonDefaults.colors(selectedColor = CosmicCyan)
                                        )
                                        Text("Publish Now", color = TextPrimary)
                                    }

                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.clickable { isScheduled = true }
                                    ) {
                                        RadioButton(
                                            selected = isScheduled,
                                            onClick = { isScheduled = true },
                                            colors = RadioButtonDefaults.colors(selectedColor = CosmicCyan)
                                        )
                                        Text("Schedule Post", color = TextPrimary)
                                    }
                                }

                                if (isScheduled) {
                                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            OutlinedTextField(
                                                value = scheduledDateText,
                                                onValueChange = { scheduledDateText = it },
                                                label = { Text("Date (YYYY-MM-DD)") },
                                                modifier = Modifier.weight(1f),
                                                shape = RoundedCornerShape(10.dp),
                                                colors = customTextFieldColors()
                                            )
                                            OutlinedTextField(
                                                value = scheduledTimeText,
                                                onValueChange = { scheduledTimeText = it },
                                                label = { Text("Time (HH:MM)") },
                                                modifier = Modifier.weight(1f),
                                                shape = RoundedCornerShape(10.dp),
                                                colors = customTextFieldColors()
                                            )
                                        }

                                        Text("Time Zone: $selectedTimeZone", fontSize = 11.sp, color = CosmicCyan)
                                    }
                                }
                            }
                        }
                    }

                    // STEP 7: Publish / Save Mission
                    item {
                        Button(
                            onClick = {
                                val schedTime = if (isScheduled) System.currentTimeMillis() + 172800000L else 0L
                                viewModel.saveProject(
                                    title = topicInput.ifBlank { "Galactic Content Mission" },
                                    niche = selectedNiche,
                                    hook = generatedHook,
                                    body = generatedScript,
                                    cta = generatedCta,
                                    voiceoverStyle = selectedVoiceover,
                                    format = selectedFormat,
                                    visualStyle = selectedVisualStyle,
                                    platforms = selectedPlatforms,
                                    scheduledTime = schedTime,
                                    contentType = selectedContentType,
                                    timeZone = selectedTimeZone
                                )
                                onProjectCreated()
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("publish_final_btn"),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = CosmicCyan)
                        ) {
                            Icon(
                                imageVector = if (isScheduled) Icons.Default.Event else Icons.Default.RocketLaunch,
                                contentDescription = null,
                                tint = StudioDarkBackground
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isScheduled) "Schedule Mission Broadcast" else "Publish Mission Now",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 15.sp,
                                color = StudioDarkBackground
                            )
                        }
                    }

                    item { Spacer(modifier = Modifier.height(24.dp)) }
                }
            }
        }
    }
}

@Composable
private fun WorkflowStepCard(
    stepNumber: String,
    title: String,
    content: @Composable () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = StudioDarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    shape = CircleShape,
                    color = PurpleContainer,
                    modifier = Modifier.size(26.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = stepNumber,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = OnPurpleContainer
                        )
                    }
                }

                Text(
                    text = title,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            }
            HorizontalDivider(color = StudioBorder)
            content()
        }
    }
}

@Composable
private fun GalacticAiAssistantSection(
    viewModel: FacelessViewModel,
    topicInput: String,
    onTopicChange: (String) -> Unit,
    aiAssistantState: AiAssistantState
) {
    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = StudioDarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("Galactic AI Assistant Engine", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = CosmicCyan)
                    Text("Generate viral titles, hashtags, descriptions, captions, and optimal posting times in seconds.", fontSize = 12.sp, color = TextSecondary)

                    OutlinedTextField(
                        value = topicInput,
                        onValueChange = onTopicChange,
                        label = { Text("Topic or Keyword") },
                        placeholder = { Text("e.g. AI Automation Hacks") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = customTextFieldColors()
                    )

                    Button(
                        onClick = {
                            if (topicInput.isNotBlank()) {
                                viewModel.generateAiAssistantMetadata(topicInput)
                            }
                        },
                        enabled = topicInput.isNotBlank() && aiAssistantState !is AiAssistantState.Loading,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = NebulaPurple)
                    ) {
                        if (aiAssistantState is AiAssistantState.Loading) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Consulting Galactic AI...", color = Color.White)
                        } else {
                            Icon(Icons.Default.Psychology, contentDescription = null, tint = Color.White)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Generate Full Asset Package", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        if (aiAssistantState is AiAssistantState.Success) {
            val res = aiAssistantState as AiAssistantState.Success

            item {
                StudioAiCard(title = "Suggested Viral Titles") {
                    res.titles.forEach { title ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(title, fontSize = 13.sp, color = TextPrimary, modifier = Modifier.weight(1f))
                            Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = CosmicCyan, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }

            item {
                StudioAiCard(title = "Optimized Description & Hashtags") {
                    Text("Description:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = CosmicCyan)
                    Text(res.description, fontSize = 12.sp, color = TextSecondary)
                    HorizontalDivider(color = StudioBorder)
                    Text("Hashtags:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = CosmicCyan)
                    Text(res.hashtags, fontSize = 12.sp, color = StarGold)
                }
            }

            item {
                StudioAiCard(title = "Suggested Posting Schedule") {
                    Text(res.bestTimes, fontSize = 12.sp, color = TextSecondary)
                }
            }
        }

        item { Spacer(modifier = Modifier.height(20.dp)) }
    }
}

@Composable
private fun StudioAiCard(
    title: String,
    content: @Composable () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = StudioDarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = NebulaPurple)
            HorizontalDivider(color = StudioBorder)
            content()
        }
    }
}

@Composable
private fun customTextFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedContainerColor = StudioDarkSurfaceVariant,
    unfocusedContainerColor = StudioDarkSurfaceVariant,
    focusedBorderColor = NebulaPurple,
    unfocusedBorderColor = StudioBorder,
    focusedTextColor = TextPrimary,
    unfocusedTextColor = TextPrimary,
    focusedLabelColor = NebulaPurple,
    unfocusedLabelColor = TextSecondary
)
