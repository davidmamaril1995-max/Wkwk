package com.example.ui.screens.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.ProjectEntity
import com.example.ui.navigation.Screen
import com.example.ui.theme.*
import com.example.ui.viewmodels.FacelessViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: FacelessViewModel,
    onNavigateToScreen: (Screen) -> Unit
) {
    val projectCount by viewModel.projectCount.collectAsStateWithLifecycle()
    val totalViews by viewModel.totalViews.collectAsStateWithLifecycle()
    val projects by viewModel.projects.collectAsStateWithLifecycle()
    val socialAccounts by viewModel.socialAccounts.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = NebulaPurple,
                            modifier = Modifier.size(38.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.RocketLaunch,
                                    contentDescription = "Intergalactic Logo",
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Column {
                            Text(
                                text = "Intergalactic Studio",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = TextPrimary
                            )
                            Text(
                                text = "Create Content Across the Galaxy",
                                fontSize = 11.sp,
                                color = CosmicCyanLight
                            )
                        }
                    }
                },
                actions = {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = StatusGreen.copy(alpha = 0.18f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, StatusGreen.copy(alpha = 0.5f))
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(StatusGreen)
                            )
                            Text(
                                text = "Quantum AI Online",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = StatusGreen
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = StudioDarkBackground)
            )
        },
        containerColor = StudioDarkBackground
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // Hero Banner Card - INTERGALACTIC COMMAND CENTER
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("home_hero_card"),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = StudioDarkSurface),
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, CosmicCyan.copy(alpha = 0.4f))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.linearGradient(
                                    listOf(
                                        PurpleContainer,
                                        BlueContainer,
                                        CyanContainer
                                    )
                                )
                            )
                            .padding(20.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = CosmicCyan.copy(alpha = 0.2f),
                                border = androidx.compose.foundation.BorderStroke(1.dp, CosmicCyan)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Icon(Icons.Default.Public, contentDescription = null, tint = CosmicCyanLight, modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "GALACTIC COMMAND CENTER",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = CosmicCyanLight
                                    )
                                }
                            }
                            Text(
                                text = "Automated Viral Video Engine Across the Cosmos",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = TextPrimary,
                                lineHeight = 28.sp
                            )
                            Text(
                                text = "Trending Signals • Content Lab • Multi-Orbit Auto-Scheduler",
                                fontSize = 12.sp,
                                color = TextSecondary
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Button(
                                onClick = { onNavigateToScreen(Screen.Create) },
                                colors = ButtonDefaults.buttonColors(containerColor = NebulaPurple),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.testTag("home_hero_create_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Add,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Launch New Mission", fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                    }
                }
            }

            // Stats Row
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    StatCard(
                        title = "Galactic Reach",
                        value = if (totalViews > 0) "${String.format("%.2f", totalViews / 1000000.0)}M" else "1.40M",
                        icon = Icons.Default.Public,
                        accentColor = CosmicCyan,
                        bgColor = CyanContainer,
                        textColor = OnCyanContainer,
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        title = "Active Missions",
                        value = projectCount.toString(),
                        icon = Icons.Default.RocketLaunch,
                        accentColor = NebulaPurple,
                        bgColor = PurpleContainer,
                        textColor = OnPurpleContainer,
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        title = "Transmitters",
                        value = "${socialAccounts.count { it.isConnected }}/6",
                        icon = Icons.Default.Radar,
                        accentColor = StarGold,
                        bgColor = GoldContainer,
                        textColor = OnGoldContainer,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Quick Action Buttons Grid
            item {
                Text(
                    text = "Galactic Modules",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    ActionTile(
                        title = "Trending Signals",
                        subtitle = "High Viral Scores",
                        icon = Icons.Default.Radar,
                        color = OnCyanContainer,
                        bgColor = CyanContainer,
                        onClick = { onNavigateToScreen(Screen.Trending) },
                        modifier = Modifier.weight(1f)
                    )
                    ActionTile(
                        title = "Content Lab",
                        subtitle = "Hooks & Scripts",
                        icon = Icons.Default.Science,
                        color = OnPurpleContainer,
                        bgColor = PurpleContainer,
                        onClick = { onNavigateToScreen(Screen.Create) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Social Accounts Transmitters Strip
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Connected Galactic Transmitters",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        TextButton(onClick = { onNavigateToScreen(Screen.Settings) }) {
                            Text("Configure", color = CosmicCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(socialAccounts) { account ->
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = StudioDarkSurface,
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (account.isConnected) CosmicCyan else StudioBorder
                                )
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                                ) {
                                    Icon(
                                        imageVector = when (account.platform.lowercase()) {
                                            "youtube" -> Icons.Default.PlayArrow
                                            "tiktok" -> Icons.Default.MusicNote
                                            "instagram" -> Icons.Default.CameraAlt
                                            "facebook" -> Icons.Default.ThumbUp
                                            "threads" -> Icons.Default.AlternateEmail
                                            else -> Icons.Default.Pin
                                        },
                                        contentDescription = account.platform,
                                        tint = if (account.isConnected) CosmicCyanLight else TextMuted,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Column {
                                        Text(
                                            text = account.platform,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = TextPrimary
                                        )
                                        Text(
                                            text = if (account.isConnected) account.accountHandle else "Offline",
                                            fontSize = 10.sp,
                                            color = if (account.isConnected) StatusGreen else TextMuted
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Recent Missions / Projects
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Recent Missions",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    TextButton(onClick = { onNavigateToScreen(Screen.Projects) }) {
                        Text("Mission Control", color = NebulaPurple, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            items(projects.take(3)) { project ->
                RecentProjectRow(project = project, onClick = { onNavigateToScreen(Screen.Projects) })
            }

            item { Spacer(modifier = Modifier.height(20.dp)) }
        }
    }
}

@Composable
private fun StatCard(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accentColor: Color,
    bgColor: Color,
    textColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = bgColor),
        border = androidx.compose.foundation.BorderStroke(1.dp, accentColor.copy(alpha = 0.3f))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = textColor, modifier = Modifier.size(20.dp))
            Text(text = value, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = textColor)
            Text(text = title, fontSize = 11.sp, color = textColor.copy(alpha = 0.8f))
        }
    }
}

@Composable
private fun ActionTile(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    bgColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = bgColor),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.3f))
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = color.copy(alpha = 0.2f)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = color,
                    modifier = Modifier
                        .padding(8.dp)
                        .size(22.dp)
                )
            }
            Column {
                Text(text = title, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = color)
                Text(text = subtitle, fontSize = 10.sp, color = color.copy(alpha = 0.8f))
            }
        }
    }
}

@Composable
private fun RecentProjectRow(
    project: ProjectEntity,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = StudioDarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder)
    ) {
        Row(
            modifier = Modifier
                .padding(12.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = PurpleContainer,
                modifier = Modifier.size(46.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.RocketLaunch,
                        contentDescription = null,
                        tint = OnPurpleContainer,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = project.title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    maxLines = 1
                )
                Text(
                    text = "${project.nicheCategory} • ${project.voiceoverStyle} • ${project.videoFormat}",
                    fontSize = 11.sp,
                    color = TextSecondary
                )
            }

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = when (project.status.lowercase()) {
                    "published" -> CyanContainer
                    "scheduled" -> GoldContainer
                    else -> StudioDarkSurfaceVariant
                }
            ) {
                Text(
                    text = project.status,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = when (project.status.lowercase()) {
                        "published" -> OnCyanContainer
                        "scheduled" -> OnGoldContainer
                        else -> TextSecondary
                    },
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }
    }
}
