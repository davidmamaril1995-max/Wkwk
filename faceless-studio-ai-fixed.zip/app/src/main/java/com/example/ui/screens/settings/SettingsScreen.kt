package com.example.ui.screens.settings

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.theme.*
import com.example.ui.viewmodels.FacelessViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: FacelessViewModel
) {
    val socialAccounts by viewModel.socialAccounts.collectAsStateWithLifecycle()

    var showApiKeyDialog by remember { mutableStateOf(false) }
    var geminiApiKeyInput by remember { mutableStateOf("") }
    var darkThemeEnabled by remember { mutableStateOf(true) }
    var pinSecurityEnabled by remember { mutableStateOf(false) }
    var backupStatusMessage by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.Tune, contentDescription = null, tint = CosmicCyan, modifier = Modifier.size(24.dp))
                        Text(
                            text = "Intergalactic Command Settings",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = TextPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = StudioDarkBackground)
            )
        },
        containerColor = StudioDarkBackground
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // API Keys & Credentials
            item {
                SettingsCategoryCard(title = "Quantum AI Credentials") {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Gemini AI Core Engine", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                                Text("Powers AI script & galactic trend discovery", fontSize = 11.sp, color = TextSecondary)
                            }

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = StatusGreen.copy(alpha = 0.18f)
                            ) {
                                Text(
                                    text = "Secrets Managed",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = StatusGreen,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Button(
                            onClick = { showApiKeyDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = PurpleContainer),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Key, contentDescription = null, tint = OnPurpleContainer)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Configure Custom API Keys", color = OnPurpleContainer, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Social Accounts Manager
            item {
                SettingsCategoryCard(title = "Orbital Transmitters & Channels") {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        socialAccounts.forEach { account ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(account.platform, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                                    Text(
                                        text = if (account.isConnected) account.accountHandle else "Transmitter Offline",
                                        fontSize = 11.sp,
                                        color = if (account.isConnected) CosmicCyan else TextMuted
                                    )
                                }

                                Switch(
                                    checked = account.isConnected,
                                    onCheckedChange = { viewModel.toggleSocialConnection(account) },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = NebulaPurple,
                                        checkedTrackColor = PurpleContainer
                                    )
                                )
                            }
                        }
                    }
                }
            }

            // Preferences & Security
            item {
                SettingsCategoryCard(title = "Cosmic Control & Vault Security") {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Dark Galactic Void Theme", fontSize = 14.sp, color = TextPrimary)
                            Switch(
                                checked = darkThemeEnabled,
                                onCheckedChange = { darkThemeEnabled = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = NebulaPurple)
                            )
                        }

                        HorizontalDivider(color = StudioBorder)

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Quantum Biometric Command Lock", fontSize = 14.sp, color = TextPrimary)
                            Switch(
                                checked = pinSecurityEnabled,
                                onCheckedChange = { pinSecurityEnabled = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = NebulaPurple)
                            )
                        }
                    }
                }
            }

            // Backup & Export
            item {
                SettingsCategoryCard(title = "Mission Vault Backup") {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "Backup all local video missions, saved galactic signals, and social broadcast schedules.",
                            fontSize = 12.sp,
                            color = TextSecondary
                        )

                        Button(
                            onClick = {
                                backupStatusMessage = "Vault Backup created at ${java.text.SimpleDateFormat("HH:mm:ss").format(java.util.Date())}"
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = NebulaPurple),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Backup, contentDescription = null, tint = Color.White)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Backup Local Vault", color = Color.White, fontWeight = FontWeight.Bold)
                        }

                        if (backupStatusMessage.isNotEmpty()) {
                            Text(text = backupStatusMessage, fontSize = 11.sp, color = StatusGreen)
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(20.dp)) }
        }
    }

    // API Keys Dialog
    if (showApiKeyDialog) {
        AlertDialog(
            onDismissRequest = { showApiKeyDialog = false },
            title = { Text("API Credentials Vault", color = TextPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "API keys are securely configured in AI Studio Secrets and injected into BuildConfig.",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                    OutlinedTextField(
                        value = geminiApiKeyInput,
                        onValueChange = { geminiApiKeyInput = it },
                        label = { Text("Override Gemini API Key") },
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = { showApiKeyDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = NebulaPurple)
                ) {
                    Text("Save", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showApiKeyDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = StudioDarkSurface
        )
    }
}

@Composable
private fun SettingsCategoryCard(
    title: String,
    content: @Composable () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = StudioDarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = title,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = NebulaPurple
            )
            HorizontalDivider(color = StudioBorder)
            content()
        }
    }
}
