package com.example.ui.screens.trending

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.TrendTopicEntity
import com.example.ui.theme.*
import com.example.ui.viewmodels.FacelessViewModel

val trendCategories = listOf(
    "All Signals",
    "Tech & AI",
    "Personal Finance",
    "Sci-Fi & Cosmos",
    "Horror & Mystery",
    "Life Hacks"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrendingScreen(
    viewModel: FacelessViewModel,
    onNavigateToCreateWithTopic: (String, String) -> Unit
) {
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val trends by viewModel.trends.collectAsStateWithLifecycle()
    var searchQuery by remember { mutableStateOf("") }
    var selectedTrendForDialog by remember { mutableStateOf<TrendTopicEntity?>(null) }

    val filteredTrends = trends.filter {
        it.topicTitle.contains(searchQuery, ignoreCase = true) ||
                it.summary.contains(searchQuery, ignoreCase = true)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.Radar, contentDescription = null, tint = CosmicCyan, modifier = Modifier.size(24.dp))
                        Text(
                            text = "Trending Signals Discovery",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = StudioDarkBackground)
            )
        },
        containerColor = StudioDarkBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Quantum Signal Scanner Search Input
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Scan galactic trend signals, keywords...", color = TextMuted) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = CosmicCyan) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear", tint = TextSecondary)
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("trending_search_input"),
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = StudioDarkSurface,
                    unfocusedContainerColor = StudioDarkSurface,
                    focusedBorderColor = CosmicCyan,
                    unfocusedBorderColor = StudioBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                singleLine = true
            )

            // Category Chips Row
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(trendCategories) { category ->
                    val isSelected = category == selectedCategory || (category == "All Signals" && selectedCategory == "All")
                    FilterChip(
                        selected = isSelected,
                        onClick = { viewModel.setCategory(if (category == "All Signals") "All" else category) },
                        label = {
                            Text(
                                text = category,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) OnCyanContainer else TextSecondary
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = CyanContainer,
                            containerColor = StudioDarkSurface
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            borderColor = if (isSelected) CosmicCyan else StudioBorder,
                            enabled = true,
                            selected = isSelected
                        )
                    )
                }
            }

            // Trends List
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(filteredTrends) { trend ->
                    TrendCard(
                        trend = trend,
                        onBookmark = { viewModel.toggleTrendSaved(trend) },
                        onClick = { selectedTrendForDialog = trend },
                        onUseTopic = { onNavigateToCreateWithTopic(trend.topicTitle, trend.category) }
                    )
                }

                item { Spacer(modifier = Modifier.height(20.dp)) }
            }
        }
    }

    // Details Dialog
    selectedTrendForDialog?.let { trend ->
        AlertDialog(
            onDismissRequest = { selectedTrendForDialog = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Radar, contentDescription = null, tint = CosmicCyan)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(trend.topicTitle, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(text = trend.summary, fontSize = 13.sp, color = TextSecondary)
                    HorizontalDivider(color = StudioBorder)
                    Text(
                        text = "Target Galaxy Audience: ${trend.targetAudience}",
                        fontSize = 12.sp,
                        color = TextPrimary
                    )
                    Text(
                        text = "Cosmic Search Volume: ${trend.searchVolume}",
                        fontSize = 12.sp,
                        color = CosmicCyan
                    )
                    Text(
                        text = "Orbital Transmitters: ${trend.recommendedPlatforms}",
                        fontSize = 12.sp,
                        color = NebulaPurpleLight
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val title = trend.topicTitle
                        val cat = trend.category
                        selectedTrendForDialog = null
                        onNavigateToCreateWithTopic(title, cat)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NebulaPurple)
                ) {
                    Text("Launch Script Lab", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedTrendForDialog = null }) {
                    Text("Close Signal", color = TextSecondary)
                }
            },
            containerColor = StudioDarkSurface,
            titleContentColor = TextPrimary
        )
    }
}

@Composable
private fun TrendCard(
    trend: TrendTopicEntity,
    onBookmark: () -> Unit,
    onClick: () -> Unit,
    onUseTopic: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("trend_card_${trend.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = StudioDarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = PurpleContainer
                ) {
                    Text(
                        text = trend.category,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = OnPurpleContainer,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = GoldContainer
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Bolt,
                                contentDescription = "Viral Score",
                                tint = StarGold,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Viral ${trend.score}/100",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = OnGoldContainer
                            )
                        }
                    }

                    IconButton(onClick = onBookmark) {
                        Icon(
                            imageVector = if (trend.isSaved) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                            contentDescription = "Bookmark Signal",
                            tint = if (trend.isSaved) CosmicCyan else TextMuted
                        )
                    }
                }
            }

            Text(
                text = trend.topicTitle,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )

            Text(
                text = trend.summary,
                fontSize = 12.sp,
                color = TextSecondary,
                maxLines = 2
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Vol: ${trend.searchVolume} • ${trend.recommendedPlatforms}",
                    fontSize = 11.sp,
                    color = TextMuted
                )

                Button(
                    onClick = onUseTopic,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = NebulaPurple),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Script Lab", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
        }
    }
}
