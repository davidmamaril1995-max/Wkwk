package com.example.ui.viewmodels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.auth.OAuthManager
import com.example.data.auth.SessionManager
import com.example.data.auth.TokenManager
import com.example.data.local.AppDatabase
import com.example.data.local.SocialAccountEntity
import com.example.data.repository.SocialAccountRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed class OAuthUiState {
    object Idle : OAuthUiState()
    object Authenticating : OAuthUiState()
    data class Success(val message: String) : OAuthUiState()
    data class Error(val message: String) : OAuthUiState()
}

data class PublishHistoryLog(
    val id: String,
    val platform: String,
    val accountHandle: String,
    val title: String,
    val status: String, // Published, Scheduled, Uploading
    val timestamp: Long = System.currentTimeMillis()
)

class SocialAuthViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val tokenManager = TokenManager(application)
    private val sessionManager = SessionManager(application)
    private val oAuthManager = OAuthManager(tokenManager)

    val repository = SocialAccountRepository(
        socialDao = db.socialAccountDao(),
        tokenManager = tokenManager,
        sessionManager = sessionManager,
        oAuthManager = oAuthManager
    )

    val accountsList: StateFlow<List<SocialAccountEntity>> = repository.getAllAccounts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val oauthState = MutableStateFlow<OAuthUiState>(OAuthUiState.Idle)

    val publishLogs = MutableStateFlow<List<PublishHistoryLog>>(
        listOf(
            PublishHistoryLog("log_1", "YouTube", "@IntergalacticStudio", "10 Secret AI Tools That Feel Illegal to Know", "Published", System.currentTimeMillis() - 3600000L),
            PublishHistoryLog("log_2", "TikTok", "@intergalactic_ai", "Terrifying Ocean Sound at 11,000m", "Published", System.currentTimeMillis() - 7200000L),
            PublishHistoryLog("log_3", "Instagram", "@intergalactic_reels", "How 19-Year-Olds Make $10k/Mo With AI", "Scheduled", System.currentTimeMillis() + 86400000L)
        )
    )

    fun connectAccountViaOAuth(platform: String, accountHandle: String) {
        viewModelScope.launch {
            oauthState.value = OAuthUiState.Authenticating
            try {
                val created = repository.connectNewAccountViaOAuth(platform, accountHandle)
                oauthState.value = OAuthUiState.Success("Successfully authenticated ${created.accountHandle} on $platform!")
            } catch (e: Exception) {
                oauthState.value = OAuthUiState.Error(e.message ?: "OAuth authentication failed")
            }
        }
    }

    fun switchActiveTarget(platform: String, accountId: Long) {
        viewModelScope.launch {
            repository.switchActiveAccount(platform, accountId)
        }
    }

    fun disconnectAccount(accountId: Long) {
        viewModelScope.launch {
            repository.disconnectAccount(accountId)
        }
    }

    fun refreshOAuthTokens(account: SocialAccountEntity) {
        viewModelScope.launch {
            try {
                val updated = repository.refreshToken(account)
                oauthState.value = OAuthUiState.Success("Tokens refreshed for ${updated.accountHandle}")
            } catch (e: Exception) {
                oauthState.value = OAuthUiState.Error("Token refresh failed: ${e.message}")
            }
        }
    }

    fun updatePermissions(accountId: Long, publishing: Boolean, scheduling: Boolean, analytics: Boolean) {
        viewModelScope.launch {
            repository.updatePermissions(accountId, publishing, scheduling, analytics)
        }
    }

    fun clearState() {
        oauthState.value = OAuthUiState.Idle
    }
}
